# ChatApp - Production-Ready Android Chat Application

A feature-rich WhatsApp-like chat application built with Kotlin, Firebase, Gemini AI, and Cloudinary.

## 🚀 Features

### Core Features
- ✅ Phone number authentication
- ✅ One-on-one chat
- ✅ Group chat (create, join, manage)
- ✅ Status updates
- ✅ Voice/Video calls
- ✅ Media sharing (images, videos, audio, files)
- ✅ Real-time messaging with Firebase Firestore
- ✅ Push notifications

### AI Features (Gemini AI)
- ✅ AI Assistant in chat - tap to get AI help
- ✅ Smart reply suggestions
- ✅ AI-powered event scheduling from messages
- ✅ Context-aware responses

### Message Actions
- ✅ Long press to: Delete, Pin, Share
- ✅ Schedule Event - AI extracts event info from selected message
- ✅ Reply to messages
- ✅ Reactions

### Offline Chat
- ✅ WiFi Direct & Bluetooth connectivity
- ✅ Create offline chat rooms with 6-digit codes
- ✅ Nearby device discovery
- ✅ Peer-to-peer messaging without internet

### Professional UI
- ✅ Material Design 3
- ✅ Smooth animations
- ✅ Dark mode support
- ✅ Professional color scheme

## 📋 Prerequisites

- Android Studio (latest version)
- JDK 17+
- Firebase account
- Gemini AI API key
- Cloudinary account

## 🔧 Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/ChatApp.git
cd ChatApp
```

### 2. Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project
3. Add an Android app with package name: `com.chatapp`
4. Download `google-services.json`
5. Place it in `app/` directory
6. Enable in Firebase Console:
   - Authentication (Phone)
   - Cloud Firestore
   - Cloud Storage
   - Cloud Messaging

#### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }
    
    match /chats/{chatId} {
      allow read, write: if request.auth != null && 
        request.auth.uid in resource.data.participants;
    }
    
    match /messages/{messageId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

#### Storage Security Rules

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /chat_media/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.resource.size < 10 * 1024 * 1024;
    }
  }
}
```

### 3. Gemini AI Setup

1. Get API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Add to GitHub Secrets or local environment

### 4. Cloudinary Setup

1. Sign up at [Cloudinary](https://cloudinary.com/)
2. Get your credentials:
   - Cloud Name
   - API Key
   - API Secret

### 5. Environment Variables

#### For Local Development

Create `local.properties` (not committed to git):

```properties
GEMINI_API_KEY=your_gemini_api_key
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

#### For GitHub Actions

Add these secrets in GitHub: Settings → Secrets and variables → Actions:

- `GEMINI_API_KEY`
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`
- `GOOGLE_SERVICES_JSON` (paste entire content of google-services.json)

### 6. Build the APK

#### Local Build

```bash
./gradlew assembleDebug
```

APK location: `app/build/outputs/apk/debug/app-debug.apk`

#### GitHub Actions Build

1. Push to `main` or `develop` branch
2. GitHub Actions automatically builds APK
3. Download from Actions tab → Artifacts

## 📱 Project Structure

```
ChatApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/chatapp/
│   │       │   ├── data/
│   │       │   │   ├── model/          # Data models
│   │       │   │   ├── local/          # Room database
│   │       │   │   ├── remote/         # Firebase services
│   │       │   │   └── repository/     # Data repositories
│   │       │   ├── ui/
│   │       │   │   ├── auth/           # Authentication screens
│   │       │   │   ├── main/           # Main screen
│   │       │   │   ├── chat/           # Chat screen
│   │       │   │   ├── group/          # Group management
│   │       │   │   ├── profile/        # User profile
│   │       │   │   ├── settings/       # Settings
│   │       │   │   └── offline/        # Offline chat
│   │       │   ├── services/           # Background services
│   │       │   ├── ai/                 # Gemini AI integration
│   │       │   ├── utils/              # Utility classes
│   │       │   └── ChatApplication.kt  # Application class
│   │       └── res/                    # Resources
│   └── build.gradle
├── .github/
│   └── workflows/
│       └── build.yml                    # CI/CD workflow
├── build.gradle
├── settings.gradle
└── README.md
```

## 🎯 Key Features Implementation

### AI Assistant

```kotlin
// Tap AI button in chat to get help
val aiService = GeminiAIService()
val response = aiService.generateResponse(userMessage, context)
```

### Schedule Event from Message

```kotlin
// Long press message → Schedule Event
val event = aiService.extractEventFromMessage(message.text)
// AI automatically extracts: title, time, location
```

### Offline Chat

```kotlin
// Create room: generates 6-digit code
// Join room: enter code to connect
// Uses Google Nearby Connections API
```

## 🔒 Permissions

The app requests these permissions:
- Camera (for photos/videos)
- Storage (for media)
- Contacts (for phone numbers)
- Location (for offline chat)
- Bluetooth (for offline chat)
- Microphone (for voice messages)
- Notifications

## 🚀 Deployment

### Production Build

1. Create signing keystore:

```bash
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-alias
```

2. Add to `app/build.gradle`:

```gradle
android {
    signingConfigs {
        release {
            storeFile file("release-key.jks")
            storePassword "your_password"
            keyAlias "my-alias"
            keyPassword "your_password"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

3. Build release APK:

```bash
./gradlew assembleRelease
```

## 📊 Architecture

- **MVVM Pattern**: ViewModels + LiveData/Flow
- **Repository Pattern**: Single source of truth
- **Dependency Injection**: Manual DI (can add Hilt)
- **Coroutines**: Asynchronous operations
- **Firebase**: Backend services
- **Room**: Local caching
- **Coil**: Image loading

## 🧪 Testing

```bash
# Unit tests
./gradlew test

# Instrumented tests
./gradlew connectedAndroidTest
```

## 📦 Libraries Used

- **Firebase**: Auth, Firestore, Storage, Messaging
- **Gemini AI**: AI-powered features
- **Cloudinary**: Media storage and optimization
- **Nearby Connections**: Offline chat
- **Coil**: Image loading
- **Room**: Local database
- **Coroutines**: Async programming
- **Material Design 3**: UI components

## 🐛 Troubleshooting

### Build Errors

1. **Google Services JSON missing**:
   - Add `google-services.json` to `app/` directory

2. **API Keys not found**:
   - Check environment variables or GitHub Secrets

3. **Gradle sync fails**:
   - File → Invalidate Caches → Restart

### Runtime Errors

1. **Firebase connection fails**:
   - Verify `google-services.json` package name matches `com.chatapp`

2. **AI features not working**:
   - Verify Gemini API key is correct

3. **Offline chat not connecting**:
   - Enable location and Bluetooth permissions

## 📄 License

MIT License - feel free to use for your projects!

## 👨‍💻 Author

Your Name - [Your GitHub](https://github.com/yourusername)

## 🙏 Acknowledgments

- Firebase for backend infrastructure
- Google Gemini for AI capabilities
- Cloudinary for media management
- Material Design for beautiful UI

---

**Note**: This is a production-ready foundation. You may need to add additional features based on your specific requirements.
