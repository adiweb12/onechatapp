# Implementation Guide - Completing ChatApp

This guide helps you complete the remaining 30% of the app implementation.

## 🎯 Priority 1: RecyclerView Adapters (Essential)

### ChatAdapter for Main Screen

Create `app/src/main/java/com/chatapp/ui/main/ChatAdapter.kt`:

```kotlin
class ChatAdapter(private val onClick: (Chat) -> Unit) : 
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {
    
    private var chats = listOf<Chat>()
    
    fun submitList(newChats: List<Chat>) {
        chats = newChats
        notifyDataSetChanged()
    }
    
    inner class ChatViewHolder(val binding: ItemChatBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(chat: Chat) {
            binding.apply {
                textViewName.text = chat.groupName.ifEmpty { "Chat" }
                textViewLastMessage.text = chat.lastMessage
                textViewTime.text = formatTime(chat.lastMessageTime)
                
                if (chat.unreadCount > 0) {
                    textViewUnread.visibility = View.VISIBLE
                    textViewUnread.text = chat.unreadCount.toString()
                } else {
                    textViewUnread.visibility = View.GONE
                }
                
                root.setOnClickListener { onClick(chat) }
            }
        }
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ChatViewHolder(ItemChatBinding.inflate(
            LayoutInflater.from(parent.context), parent, false))
    
    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        holder.bind(chats[position])
    }
    
    override fun getItemCount() = chats.size
}
```

Create layout `res/layout/item_chat.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:padding="16dp">

    <ImageView
        android:id="@+id/imageViewProfile"
        android:layout_width="56dp"
        android:layout_height="56dp"
        android:src="@drawable/ic_launcher"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <TextView
        android:id="@+id/textViewName"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginStart="16dp"
        android:textSize="16sp"
        android:textStyle="bold"
        app:layout_constraintStart_toEndOf="@id/imageViewProfile"
        app:layout_constraintTop_toTopOf="@id/imageViewProfile"
        app:layout_constraintEnd_toStartOf="@id/textViewTime" />

    <TextView
        android:id="@+id/textViewLastMessage"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginStart="16dp"
        android:maxLines="1"
        android:ellipsize="end"
        app:layout_constraintStart_toEndOf="@id/imageViewProfile"
        app:layout_constraintTop_toBottomOf="@id/textViewName"
        app:layout_constraintEnd_toEndOf="parent" />

    <TextView
        android:id="@+id/textViewTime"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:textSize="12sp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toTopOf="@id/textViewName" />

    <TextView
        android:id="@+id/textViewUnread"
        android:layout_width="24dp"
        android:layout_height="24dp"
        android:background="@color/primary"
        android:gravity="center"
        android:textColor="@color/white"
        android:textSize="12sp"
        android:visibility="gone"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toBottomOf="@id/textViewTime" />

</androidx.constraintlayout.widget.ConstraintLayout>
```

### MessageAdapter for Chat Screen

Create `app/src/main/java/com/chatapp/ui/chat/MessageAdapter.kt`:

```kotlin
class MessageAdapter(
    private val currentUserId: String,
    private val onLongClick: (Message) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    
    private var messages = listOf<Message>()
    
    companion object {
        const val VIEW_TYPE_SENT = 1
        const val VIEW_TYPE_RECEIVED = 2
    }
    
    fun submitList(newMessages: List<Message>) {
        messages = newMessages
        notifyDataSetChanged()
    }
    
    override fun getItemViewType(position: Int) = 
        if (messages[position].senderId == currentUserId) 
            VIEW_TYPE_SENT else VIEW_TYPE_RECEIVED
    
    inner class SentMessageViewHolder(val binding: ItemMessageSentBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(message: Message) {
            binding.textViewMessage.text = message.text
            binding.textViewTime.text = formatTime(message.timestamp)
            
            if (message.isPinned) {
                binding.iconPin.visibility = View.VISIBLE
            }
            
            binding.root.setOnLongClickListener {
                onLongClick(message)
                true
            }
        }
    }
    
    // Similar for ReceivedMessageViewHolder...
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        when (viewType) {
            VIEW_TYPE_SENT -> SentMessageViewHolder(
                ItemMessageSentBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false))
            else -> ReceivedMessageViewHolder(...)
        }
    
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is SentMessageViewHolder -> holder.bind(messages[position])
            is ReceivedMessageViewHolder -> holder.bind(messages[position])
        }
    }
    
    override fun getItemCount() = messages.size
}
```

## 🎯 Priority 2: ViewModels (Important)

### AuthViewModel

Create `app/src/main/java/com/chatapp/ui/auth/AuthViewModel.kt`:

```kotlin
class AuthViewModel : ViewModel() {
    private val repository = AuthRepository()
    
    private val _authState = MutableLiveData<AuthState>()
    val authState: LiveData<AuthState> = _authState
    
    fun signIn(credential: PhoneAuthCredential) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            repository.signInWithCredential(credential)
                .onSuccess { user ->
                    _authState.value = AuthState.Success(user)
                }
                .onFailure { error ->
                    _authState.value = AuthState.Error(error.message ?: "Unknown error")
                }
        }
    }
}

sealed class AuthState {
    object Loading : AuthState()
    data class Success(val user: User) : AuthState()
    data class Error(val message: String) : AuthState()
}
```

### ChatViewModel

```kotlin
class ChatViewModel(private val chatId: String) : ViewModel() {
    private val repository = ChatRepository()
    
    val messages = repository.getMessages(chatId)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    
    fun sendMessage(text: String) {
        viewModelScope.launch {
            val message = Message(
                chatId = chatId,
                senderId = FirebaseAuth.getInstance().currentUser?.uid ?: "",
                text = text,
                timestamp = System.currentTimeMillis()
            )
            repository.sendMessage(message)
        }
    }
    
    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }
}
```

## 🎯 Priority 3: Complete Activity Implementations

### Update ChatActivity to use ViewModel

```kotlin
class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private lateinit var viewModel: ChatViewModel
    private lateinit var adapter: MessageAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        val chatId = intent.getStringExtra("chatId") ?: return finish()
        viewModel = ViewModelProvider(this, 
            ChatViewModelFactory(chatId))[ChatViewModel::class.java]
        
        setupRecyclerView()
        setupInput()
        observeMessages()
    }
    
    private fun setupRecyclerView() {
        adapter = MessageAdapter(
            FirebaseAuth.getInstance().currentUser?.uid ?: "",
            onLongClick = { message -> showMessageOptions(message) }
        )
        
        binding.recyclerViewMessages.apply {
            layoutManager = LinearLayoutManager(this@ChatActivity)
            adapter = this@ChatActivity.adapter
        }
    }
    
    private fun setupInput() {
        binding.btnSend.setOnClickListener {
            val text = binding.editTextMessage.text.toString()
            if (text.isNotBlank()) {
                viewModel.sendMessage(text)
                binding.editTextMessage.text?.clear()
            }
        }
        
        binding.btnAI.setOnClickListener {
            showAIAssistant()
        }
    }
    
    private fun observeMessages() {
        lifecycleScope.launch {
            viewModel.messages.collect { messages ->
                adapter.submitList(messages)
                binding.recyclerViewMessages.scrollToPosition(messages.size - 1)
            }
        }
    }
    
    private fun showMessageOptions(message: Message) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Message Actions")
            .setItems(arrayOf("Delete", "Pin", "Share", "Schedule Event")) { _, which ->
                when (which) {
                    0 -> viewModel.deleteMessage(message.id)
                    1 -> viewModel.pinMessage(message.id, !message.isPinned)
                    2 -> shareMessage(message.text)
                    3 -> scheduleEvent(message)
                }
            }
            .show()
    }
    
    private fun scheduleEvent(message: Message) {
        lifecycleScope.launch {
            val aiService = GeminiAIService()
            val event = aiService.extractEventFromMessage(message.text)
            if (event != null) {
                // Show event creation dialog
                showEventDialog(event)
            } else {
                Toast.makeText(this@ChatActivity, 
                    "No event information found", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
```

## 🎯 Priority 4: Offline Chat Implementation

### Complete OfflineChatActivity

```kotlin
class OfflineChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOfflineChatBinding
    private val connectionService = OfflineConnectionService()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOfflineChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        checkPermissions()
        setupUI()
    }
    
    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.NEARBY_WIFI_DEVICES
        )
        
        ActivityCompat.requestPermissions(this, permissions, 100)
    }
    
    private fun setupUI() {
        binding.btnCreateRoom.setOnClickListener {
            createOfflineRoom()
        }
        
        binding.btnJoinRoom.setOnClickListener {
            joinOfflineRoom()
        }
    }
    
    private fun createOfflineRoom() {
        val code = (100000..999999).random().toString()
        
        // Show code to user
        MaterialAlertDialogBuilder(this)
            .setTitle("Room Created")
            .setMessage("Share this code with nearby users:\n\n$code")
            .setPositiveButton("OK", null)
            .show()
        
        // Start advertising
        val intent = Intent(this, OfflineConnectionService::class.java)
        intent.action = OfflineConnectionService.ACTION_CREATE_ROOM
        intent.putExtra(OfflineConnectionService.EXTRA_ROOM_CODE, code)
        startService(intent)
    }
    
    private fun joinOfflineRoom() {
        val input = EditText(this)
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Enter Room Code")
            .setView(input)
            .setPositiveButton("Join") { _, _ ->
                val code = input.text.toString()
                if (code.length == 6) {
                    val intent = Intent(this, OfflineConnectionService::class.java)
                    intent.action = OfflineConnectionService.ACTION_JOIN_ROOM
                    intent.putExtra(OfflineConnectionService.EXTRA_ROOM_CODE, code)
                    startService(intent)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
```

## 📱 Additional UI Enhancements

### Message Bubbles

Create `res/drawable/bg_message_sent.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/message_sent"/>
    <corners android:radius="16dp"/>
    <padding android:left="12dp" android:right="12dp" 
             android:top="8dp" android:bottom="8dp"/>
</shape>
```

Similar for `bg_message_received.xml` with different color.

### Loading States

Add ProgressBar to layouts:

```xml
<ProgressBar
    android:id="@+id/progressBar"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:visibility="gone"
    app:layout_constraintTop_toTopOf="parent"
    app:layout_constraintBottom_toBottomOf="parent"
    app:layout_constraintStart_toStartOf="parent"
    app:layout_constraintEnd_toEndOf="parent" />
```

## 🧪 Testing Your Implementation

### Test Checklist

1. **Authentication**
   - [ ] Phone number validation
   - [ ] Code verification
   - [ ] Error handling

2. **Chat**
   - [ ] Send text messages
   - [ ] Receive messages in real-time
   - [ ] Message timestamps
   - [ ] Long press actions

3. **AI Features**
   - [ ] AI Assistant responds
   - [ ] Event extraction works
   - [ ] Smart replies

4. **Offline**
   - [ ] Room creation
   - [ ] Code joining
   - [ ] Message transmission

5. **Media**
   - [ ] Image upload to Cloudinary
   - [ ] Image display in messages

## 🚀 Deployment Checklist

- [ ] Update app version in build.gradle
- [ ] Test on multiple devices
- [ ] Verify all permissions
- [ ] Test with real phone numbers
- [ ] Check Firestore rules
- [ ] Verify API keys in GitHub Secrets
- [ ] Build release APK
- [ ] Test release APK

## 📚 Resources

- [Firebase Android Documentation](https://firebase.google.com/docs/android/setup)
- [Material Design 3](https://m3.material.io/)
- [Gemini AI API](https://ai.google.dev/)
- [Nearby Connections](https://developers.google.com/nearby/connections/overview)

---

**With these implementations, your app will be 100% complete!**
