# Complete Setup Guide for ChatApp

## ⚡ Quick Start

This guide will help you get the ChatApp running and building APKs via GitHub Actions.

## 📋 Prerequisites Checklist

- [ ] GitHub account
- [ ] Firebase account (free)
- [ ] Gemini AI API key (free)
- [ ] Cloudinary account (free)

## 🔥 Step 1: Firebase Setup (15 minutes)

### 1.1 Create Firebase Project

1. Go to https://console.firebase.google.com/
2. Click "Add project"
3. Enter project name: `ChatApp` (or your choice)
4. Disable Google Analytics (optional)
5. Click "Create project"

### 1.2 Add Android App

1. Click the Android icon
2. Enter package name: `com.chatapp`
3. App nickname: `ChatApp`
4. Click "Register app"
5. **Download `google-services.json`**
6. Save it for later (you'll need to add it to GitHub)

### 1.3 Enable Firebase Services

#### Authentication
1. In Firebase Console, go to Build → Authentication
2. Click "Get started"
3. Click "Phone" under Sign-in method
4. Enable it and Save

#### Cloud Firestore
1. Go to Build → Firestore Database
2. Click "Create database"
3. Choose "Start in production mode"
4. Select location closest to you
5. Click "Enable"

#### Update Firestore Rules
1. Go to Firestore → Rules
2. Replace with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }
    
    match /chats/{chatId} {
      allow read, write: if request.auth != null;
    }
    
    match /messages/{messageId} {
      allow read, write: if request.auth != null;
    }
    
    match /events/{eventId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

3. Click "Publish"

#### Cloud Storage
1. Go to Build → Storage
2. Click "Get started"
3. Start in production mode
4. Choose same location as Firestore
5. Click "Done"

#### Update Storage Rules
1. Go to Storage → Rules
2. Replace with:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /chat_media/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.resource.size < 10 * 1024 * 1024;
    }
    match /profile_images/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.resource.size < 5 * 1024 * 1024;
    }
  }
}
```

3. Click "Publish"

#### Cloud Messaging (for notifications)
1. Go to Build → Cloud Messaging
2. It's enabled by default
3. Note: You'll configure this later

## 🤖 Step 2: Gemini AI Setup (5 minutes)

1. Go to https://makersuite.google.com/app/apikey
2. Click "Create API Key"
3. Choose "Create API key in new project"
4. Copy the API key (starts with `AIza...`)
5. Save it somewhere safe

## ☁️ Step 3: Cloudinary Setup (5 minutes)

1. Go to https://cloudinary.com/users/register/free
2. Sign up for free account
3. After login, go to Dashboard
4. Note these values:
   - **Cloud Name** (e.g., `dxxxxx`)
   - **API Key** (e.g., `123456789012345`)
   - **API Secret** (click "Reveal" to see it)
5. Save all three values

## 📦 Step 4: GitHub Repository Setup (10 minutes)

### 4.1 Fork or Clone

Option A: Fork this repository on GitHub
Option B: Create new repo and push this code

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/ChatApp.git
git push -u origin main
```

### 4.2 Add GitHub Secrets

1. Go to your GitHub repository
2. Click Settings → Secrets and variables → Actions
3. Click "New repository secret"
4. Add these secrets ONE BY ONE:

#### Secret 1: GEMINI_API_KEY
- Name: `GEMINI_API_KEY`
- Value: Your Gemini API key from Step 2

#### Secret 2: CLOUDINARY_CLOUD_NAME
- Name: `CLOUDINARY_CLOUD_NAME`
- Value: Your Cloudinary cloud name

#### Secret 3: CLOUDINARY_API_KEY
- Name: `CLOUDINARY_API_KEY`
- Value: Your Cloudinary API key

#### Secret 4: CLOUDINARY_API_SECRET
- Name: `CLOUDINARY_API_SECRET`
- Value: Your Cloudinary API secret

#### Secret 5: GOOGLE_SERVICES_JSON
- Name: `GOOGLE_SERVICES_JSON`
- Value: **Entire contents** of your `google-services.json` file
- Open the file you downloaded in Step 1.2
- Copy EVERYTHING (including { and })
- Paste as the secret value

### 4.3 Verify Secrets

You should have 5 secrets:
- ✅ GEMINI_API_KEY
- ✅ CLOUDINARY_CLOUD_NAME
- ✅ CLOUDINARY_API_KEY
- ✅ CLOUDINARY_API_SECRET
- ✅ GOOGLE_SERVICES_JSON

## 🚀 Step 5: Build Your APK (2 minutes)

### Option A: Automatic Build (Recommended)

1. Go to your GitHub repository
2. Make any small change (e.g., edit README.md)
3. Commit and push:

```bash
git add .
git commit -m "Trigger build"
git push
```

4. Go to Actions tab in GitHub
5. Watch the build progress (takes 5-10 minutes)
6. Once complete, download the APK from Artifacts

### Option B: Manual Trigger

1. Go to Actions tab
2. Click "Build APK" workflow
3. Click "Run workflow"
4. Click green "Run workflow" button
5. Wait for completion
6. Download APK from Artifacts

## 📱 Step 6: Install & Test

1. Download the APK from GitHub Actions artifacts
2. Transfer to your Android phone
3. Enable "Install from unknown sources" if needed
4. Install the APK
5. Open ChatApp
6. Grant all permissions
7. Test phone authentication

## ✅ Testing Checklist

- [ ] App launches successfully
- [ ] Can sign in with phone number
- [ ] Can create/view profile
- [ ] Can send text messages
- [ ] Can create group chats
- [ ] AI Assistant responds
- [ ] Schedule Event from message works
- [ ] Can upload images
- [ ] Offline chat connects

## 🐛 Troubleshooting

### Build Fails on GitHub Actions

**Error: "google-services.json not found"**
- Solution: Check GOOGLE_SERVICES_JSON secret is properly set
- Make sure you copied the ENTIRE file contents

**Error: "API key not found"**
- Solution: Verify all 5 secrets are set correctly
- Check for typos in secret names (case-sensitive)

### App Crashes on Launch

**Firebase initialization failed**
- Solution: Verify package name is exactly `com.chatapp`
- Check google-services.json has correct package name

**AI features not working**
- Solution: Check Gemini API key is valid
- Try generating a new API key

### Phone Authentication Fails

**SMS not received**
- Solution: Firebase phone auth requires a paid Firebase plan for production
- For testing, use Firebase Auth test phone numbers

### Images Not Uploading

**Cloudinary errors**
- Solution: Verify all 3 Cloudinary credentials
- Check Cloudinary account is active

## 📞 Need Help?

1. Check GitHub Issues for similar problems
2. Review Firebase Console for errors
3. Check Logcat in Android Studio for crash details

## 🎉 Success!

Your ChatApp is now ready! You can:
- Build APKs automatically on every push
- Download APKs from GitHub Actions
- Install on any Android device
- Customize features as needed

## 🔄 Continuous Development

Every time you push to `main` branch:
1. GitHub Actions automatically builds
2. APK is available in Artifacts
3. Download and test new version

## 📚 Next Steps

- Customize UI colors in `res/values/colors.xml`
- Add more AI features in `ai/GeminiAIService.kt`
- Implement voice/video calls
- Add status/stories feature
- Customize app icon

---

**Happy Coding! 🚀**
