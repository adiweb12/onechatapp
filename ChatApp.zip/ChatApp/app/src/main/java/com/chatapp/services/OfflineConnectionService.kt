package com.chatapp.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

class OfflineConnectionService : Service() {
    
    private lateinit var connectionsClient: ConnectionsClient
    private val _connectedDevices = MutableStateFlow<List<String>>(emptyList())
    val connectedDevices: StateFlow<List<String>> = _connectedDevices
    
    companion object {
        private const val SERVICE_ID = "com.chatapp.offline"
        const val ACTION_CREATE_ROOM = "CREATE_ROOM"
        const val ACTION_JOIN_ROOM = "JOIN_ROOM"
        const val EXTRA_ROOM_CODE = "ROOM_CODE"
    }
    
    override fun onCreate() {
        super.onCreate()
        connectionsClient = Nearby.getConnectionsClient(this)
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CREATE_ROOM -> {
                val roomCode = generateRoomCode()
                startAdvertising(roomCode)
            }
            ACTION_JOIN_ROOM -> {
                val roomCode = intent.getStringExtra(EXTRA_ROOM_CODE)
                if (roomCode != null) {
                    startDiscovery(roomCode)
                }
            }
        }
        return START_STICKY
    }
    
    private fun generateRoomCode(): String {
        return (100000..999999).random().toString()
    }
    
    private fun startAdvertising(roomCode: String) {
        val advertisingOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        
        connectionsClient.startAdvertising(
            roomCode,
            SERVICE_ID,
            connectionLifecycleCallback,
            advertisingOptions
        ).addOnSuccessListener {
            // Advertising started
        }.addOnFailureListener {
            // Advertising failed
        }
    }
    
    private fun startDiscovery(roomCode: String) {
        val discoveryOptions = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()
        
        connectionsClient.startDiscovery(
            SERVICE_ID,
            endpointDiscoveryCallback,
            discoveryOptions
        ).addOnSuccessListener {
            // Discovery started
        }.addOnFailureListener {
            // Discovery failed
        }
    }
    
    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }
        
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                val devices = _connectedDevices.value.toMutableList()
                devices.add(endpointId)
                _connectedDevices.value = devices
            }
        }
        
        override fun onDisconnected(endpointId: String) {
            val devices = _connectedDevices.value.toMutableList()
            devices.remove(endpointId)
            _connectedDevices.value = devices
        }
    }
    
    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            connectionsClient.requestConnection(
                "User",
                endpointId,
                connectionLifecycleCallback
            )
        }
        
        override fun onEndpointLost(endpointId: String) {}
    }
    
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val message = payload.asBytes()?.let { String(it) }
                // Handle received message
            }
        }
        
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }
    
    fun sendMessage(message: String) {
        val payload = Payload.fromBytes(message.toByteArray())
        _connectedDevices.value.forEach { endpointId ->
            connectionsClient.sendPayload(endpointId, payload)
        }
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        connectionsClient.stopAdvertising()
        connectionsClient.stopDiscovery()
        connectionsClient.stopAllEndpoints()
    }
}
