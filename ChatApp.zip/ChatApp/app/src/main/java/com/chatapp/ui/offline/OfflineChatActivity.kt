package com.chatapp.ui.offline

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chatapp.R

class OfflineChatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: Implement offline chat with Nearby Connections
    }
}
