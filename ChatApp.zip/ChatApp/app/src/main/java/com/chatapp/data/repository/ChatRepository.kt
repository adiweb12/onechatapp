package com.chatapp.data.repository

import com.chatapp.data.model.Chat
import com.chatapp.data.model.Message
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ChatRepository {
    
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    private val currentUserId = auth.currentUser?.uid ?: ""
    
    suspend fun createChat(chat: Chat): Result<String> {
        return try {
            val docRef = firestore.collection("chats").document()
            val chatWithId = chat.copy(id = docRef.id)
            docRef.set(chatWithId).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun getChats(): Flow<List<Chat>> = callbackFlow {
        val listener = firestore.collection("chats")
            .whereArrayContains("participants", currentUserId)
            .orderBy("lastMessageTime", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                
                val chats = snapshot?.documents?.mapNotNull { 
                    it.toObject(Chat::class.java)
                } ?: emptyList()
                
                trySend(chats)
            }
        
        awaitClose { listener.remove() }
    }
    
    suspend fun sendMessage(message: Message): Result<Unit> {
        return try {
            val docRef = firestore.collection("messages").document()
            val messageWithId = message.copy(id = docRef.id)
            docRef.set(messageWithId).await()
            
            // Update last message in chat
            firestore.collection("chats")
                .document(message.chatId)
                .update(
                    mapOf(
                        "lastMessage" to message.text,
                        "lastMessageTime" to message.timestamp
                    )
                )
                .await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun getMessages(chatId: String): Flow<List<Message>> = callbackFlow {
        val listener = firestore.collection("messages")
            .whereEqualTo("chatId", chatId)
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                
                val messages = snapshot?.documents?.mapNotNull { 
                    it.toObject(Message::class.java)
                } ?: emptyList()
                
                trySend(messages)
            }
        
        awaitClose { listener.remove() }
    }
    
    suspend fun deleteMessage(messageId: String): Result<Unit> {
        return try {
            firestore.collection("messages")
                .document(messageId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun pinMessage(messageId: String, isPinned: Boolean): Result<Unit> {
        return try {
            firestore.collection("messages")
                .document(messageId)
                .update("isPinned", isPinned)
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
