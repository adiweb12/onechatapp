package com.chatapp.ai

import com.chatapp.BuildConfig
import com.chatapp.data.model.Event
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class GeminiAIService {
    
    private val model = GenerativeModel(
        modelName = "gemini-pro",
        apiKey = BuildConfig.GEMINI_API_KEY
    )
    
    suspend fun generateResponse(userMessage: String, context: String = ""): String {
        return withContext(Dispatchers.IO) {
            try {
                val prompt = if (context.isNotEmpty()) {
                    "Context: $context\n\nUser message: $userMessage\n\nProvide a helpful response:"
                } else {
                    userMessage
                }
                
                val response = model.generateContent(prompt)
                response.text ?: "I couldn't generate a response. Please try again."
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        }
    }
    
    suspend fun extractEventFromMessage(message: String): Event? {
        return withContext(Dispatchers.IO) {
            try {
                val prompt = """
                    Extract event information from this message: "$message"
                    
                    Return ONLY a JSON object with these fields:
                    {
                        "title": "event title",
                        "description": "brief description",
                        "startTime": "ISO 8601 datetime or empty",
                        "location": "location or empty"
                    }
                    
                    If no event information is found, return: {"title": ""}
                """.trimIndent()
                
                val response = model.generateContent(prompt)
                val jsonText = response.text?.trim() ?: return@withContext null
                
                // Extract JSON from markdown code blocks if present
                val jsonString = if (jsonText.startsWith("```")) {
                    jsonText.substringAfter("```json").substringAfter("```").substringBefore("```").trim()
                } else {
                    jsonText
                }
                
                val json = JSONObject(jsonString)
                val title = json.optString("title", "")
                
                if (title.isEmpty()) return@withContext null
                
                Event(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    description = json.optString("description", ""),
                    startTime = parseDateTime(json.optString("startTime", "")),
                    location = json.optString("location", ""),
                    createdAt = System.currentTimeMillis()
                )
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
    
    suspend fun getSmartReply(message: String, conversationHistory: List<String> = emptyList()): List<String> {
        return withContext(Dispatchers.IO) {
            try {
                val context = if (conversationHistory.isNotEmpty()) {
                    "Recent conversation:\n${conversationHistory.takeLast(5).joinToString("\n")}\n\n"
                } else {
                    ""
                }
                
                val prompt = """
                    ${context}Last message: "$message"
                    
                    Generate 3 short, natural reply suggestions (max 10 words each).
                    Return as JSON array: ["reply1", "reply2", "reply3"]
                """.trimIndent()
                
                val response = model.generateContent(prompt)
                val jsonText = response.text?.trim() ?: return@withContext emptyList()
                
                // Parse JSON array
                val jsonString = if (jsonText.startsWith("```")) {
                    jsonText.substringAfter("[").substringBefore("]")
                } else {
                    jsonText.substringAfter("[").substringBefore("]")
                }
                
                jsonString.split(",")
                    .map { it.trim().removeSurrounding("\"") }
                    .take(3)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    
    private fun parseDateTime(dateTimeStr: String): Long {
        if (dateTimeStr.isEmpty()) return 0
        
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
            format.parse(dateTimeStr)?.time ?: 0
        } catch (e: Exception) {
            0
        }
    }
}
