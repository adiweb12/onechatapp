package com.chatapp.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.chatapp.R
import com.chatapp.data.repository.ChatRepository
import com.chatapp.ui.chat.ChatActivity
import com.chatapp.ui.offline.OfflineChatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private val auth = FirebaseAuth.getInstance()
    private val chatRepository = ChatRepository()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        setupUI()
        loadChats()
    }
    
    private fun setupUI() {
        // Setup toolbar
        // Setup bottom navigation
        // Setup FAB for new chat
        // Setup tabs: Chats, Status, Calls
    }
    
    private fun loadChats() {
        lifecycleScope.launch {
            chatRepository.getChats().collect { chats ->
                // Update RecyclerView with chats
            }
        }
    }
    
    private fun openChat(chatId: String) {
        val intent = Intent(this, ChatActivity::class.java)
        intent.putExtra("chatId", chatId)
        startActivity(intent)
    }
    
    private fun openOfflineChat() {
        val intent = Intent(this, OfflineChatActivity::class.java)
        startActivity(intent)
    }
}
