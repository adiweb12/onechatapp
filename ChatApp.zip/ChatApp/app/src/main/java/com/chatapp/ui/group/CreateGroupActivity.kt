package com.chatapp.ui.group

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chatapp.R

class CreateGroupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: Implement group creation
    }
}
