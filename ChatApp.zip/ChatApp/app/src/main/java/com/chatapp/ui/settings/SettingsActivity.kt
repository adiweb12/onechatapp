package com.chatapp.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chatapp.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: Implement settings
    }
}
