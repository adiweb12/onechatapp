package com.chatapp.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Chat(
    val id: String = "",
    val type: ChatType = ChatType.PRIVATE,
    val participants: List<String> = emptyList(),
    val groupName: String = "",
    val groupImageUrl: String = "",
    val lastMessage: String = "",
    val lastMessageTime: Long = 0,
    val unreadCount: Int = 0,
    val createdBy: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

enum class ChatType {
    PRIVATE, GROUP
}
