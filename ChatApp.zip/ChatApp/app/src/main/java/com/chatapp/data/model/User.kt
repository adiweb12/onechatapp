package com.chatapp.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val id: String = "",
    val phoneNumber: String = "",
    val name: String = "",
    val profileImageUrl: String = "",
    val status: String = "",
    val isOnline: Boolean = false,
    val lastSeen: Long = 0,
    val fcmToken: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
