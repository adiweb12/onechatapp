package com.chatapp.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Message(
    val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val type: MessageType = MessageType.TEXT,
    val mediaUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isPinned: Boolean = false,
    val replyToMessageId: String = "",
    val reactions: Map<String, String> = emptyMap()
) : Parcelable

enum class MessageType {
    TEXT, IMAGE, VIDEO, AUDIO, FILE, LOCATION
}
