package com.chatapp.ui.profile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chatapp.R

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // TODO: Implement user profile
    }
}
