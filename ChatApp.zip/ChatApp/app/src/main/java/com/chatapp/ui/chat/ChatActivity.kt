package com.chatapp.ui.chat

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.chatapp.R
import com.chatapp.ai.GeminiAIService
import com.chatapp.data.model.Message
import com.chatapp.data.model.MessageType
import com.chatapp.data.repository.ChatRepository
import com.chatapp.utils.CloudinaryUploader
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {
    
    private val auth = FirebaseAuth.getInstance()
    private val chatRepository = ChatRepository()
    private val aiService = GeminiAIService()
    private lateinit var cloudinaryUploader: CloudinaryUploader
    private var chatId: String = ""
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        
        chatId = intent.getStringExtra("chatId") ?: ""
        cloudinaryUploader = CloudinaryUploader(this)
        
        setupUI()
        loadMessages()
    }
    
    private fun setupUI() {
        // Setup toolbar with chat name/image
        // Setup RecyclerView for messages
        // Setup message input
        // Setup send button
        // Setup attachment button
        // Setup AI assistant button
    }
    
    private fun loadMessages() {
        lifecycleScope.launch {
            chatRepository.getMessages(chatId).collect { messages ->
                // Update RecyclerView
            }
        }
    }
    
    private fun sendMessage(text: String) {
        val message = Message(
            chatId = chatId,
            senderId = auth.currentUser?.uid ?: "",
            senderName = auth.currentUser?.displayName ?: "",
            text = text,
            type = MessageType.TEXT,
            timestamp = System.currentTimeMillis()
        )
        
        lifecycleScope.launch {
            chatRepository.sendMessage(message)
        }
    }
    
    private fun showAIAssistant(context: String) {
        lifecycleScope.launch {
            try {
                val response = aiService.generateResponse("Help with: $context")
                // Show response in dialog or copy to clipboard
                Toast.makeText(this@ChatActivity, "AI Response copied!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@ChatActivity, "AI failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun scheduleEventFromMessage(message: Message) {
        lifecycleScope.launch {
            try {
                val event = aiService.extractEventFromMessage(message.text)
                if (event != null) {
                    // Show event creation dialog with pre-filled details
                    Toast.makeText(this@ChatActivity, "Event created: ${event.title}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@ChatActivity, "No event info found in message", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ChatActivity, "Failed to create event", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun onMessageLongPress(message: Message) {
        // Show dialog with options:
        // - Delete
        // - Pin
        // - Share
        // - Schedule Event
    }
}
