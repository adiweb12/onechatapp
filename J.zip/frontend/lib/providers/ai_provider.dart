import 'package:flutter/foundation.dart';

class AIProvider with ChangeNotifier {
  String? _token;

  void initialize(String? token) {
    _token = token;
  }
}
